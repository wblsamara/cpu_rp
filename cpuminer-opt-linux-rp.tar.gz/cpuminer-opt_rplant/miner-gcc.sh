#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a yescryptr16 -o stratum+tcp://pool.rplant.xyz:3333 -u GPmjG5QuNDjCC3mUd9qZr6YeSq6JqaKVZD.WORKER_NAME
done
